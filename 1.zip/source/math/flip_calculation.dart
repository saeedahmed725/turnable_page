import 'dart:math' as math;
import 'package:flutter/painting.dart';
import '../enums/flip_corner.dart';
import '../enums/flip_direction.dart';
import 'helper.dart';

/// Port of original FlipCalculation but using [Offset].
class FlipCalculation {
  /// Current rotation angle (always positive, sign applied in display logic)
  late double angle;

  /// Active corner position (the rotation origin) in page local coordinates
  late Offset position;

  final double pageWidth;
  final double pageHeight;
  final FlipDirection direction;
  final FlipCorner corner;

  /// Intersection points with book bounds
  Offset? topIntersectPoint;
  Offset? sideIntersectPoint;
  Offset? bottomIntersectPoint;

  /// Rotated page corner points (topLeft, topRight, bottomLeft, bottomRight) in page space
  late Offset _tl;
  late Offset _tr;
  late Offset _bl;
  late Offset _br;

  /// Bounding rectangle of rotated page (used only for quick checks)
  Rect? _boundingRect;

  FlipCalculation(this.direction, this.corner, this.pageWidth, this.pageHeight);

  bool calc(Offset localPos) {
    try {
      position = _calcAngleAndPosition(localPos);
      _calculateIntersectPoint(position);
      return true;
    } catch (_) {
      return false;
    }
  }

  double get flippingProgress => ((position.dx - pageWidth) / (2 * pageWidth) * 100).abs();

  /// Active corner in rotated geometry (matches original getActiveCorner)
  Offset get activeCorner => direction == FlipDirection.forward ? _tl : _tr;

  /// Display angle with direction sign applied
  double get displayAngle => direction == FlipDirection.forward ? -angle : angle;

  /// Rotated page corner getters
  Offset get topLeft => _tl;
  Offset get topRight => _tr;
  Offset get bottomLeft => _bl;
  Offset get bottomRight => _br;

  Rect get rect => _boundingRect!;

  /// Clip polygon for the visible part of the flipping page (mirrors original getFlippingClipArea)
  List<Offset> getFlippingClipArea() {
    final poly = <Offset>[];
    bool clipBottom = false;
    poly.add(_tl);
    if (topIntersectPoint != null) poly.add(topIntersectPoint!);
    if (sideIntersectPoint == null) {
      clipBottom = true;
    } else {
      poly.add(sideIntersectPoint!);
      if (bottomIntersectPoint == null) clipBottom = false;
    }
    if (bottomIntersectPoint != null) poly.add(bottomIntersectPoint!);
    if (clipBottom || corner == FlipCorner.bottom) poly.add(_bl);
    return poly;
  }

  /// Clip polygon for the page underneath (mirrors original getBottomClipArea)
  List<Offset> getBottomClipArea() {
    // NOTE: Kept 1:1 with original algorithm in /src/flip/flip_calculation.dart
    final result = <Offset>[];

    if (topIntersectPoint != null) {
      result.add(topIntersectPoint!);
    }

    if (corner == FlipCorner.top) {
      result.add(Offset(pageWidth, 0));
    } else {
      if (topIntersectPoint != null) {
        result.add(Offset(pageWidth, 0));
      }
      result.add(Offset(pageWidth, pageHeight));
    }

    if (sideIntersectPoint != null && topIntersectPoint != null) {
      if (Helper.distance(sideIntersectPoint!, topIntersectPoint!) >= 10) {
        result.add(sideIntersectPoint!);
      }
    } else {
      if (corner == FlipCorner.top) {
        result.add(Offset(pageWidth, pageHeight));
      }
    }

    if (bottomIntersectPoint != null) {
      result.add(bottomIntersectPoint!);
    }

    if (topIntersectPoint != null) {
      result.add(topIntersectPoint!); // close polygon like original
    }

    return result;
  }

  /// Get the active corner of the page (which corner is being pulled)
  Offset getActiveCorner() {
    if (corner == FlipCorner.top) {
      return direction == FlipDirection.forward ? _tl : _tr;
    } else {
      return direction == FlipDirection.forward ? _bl : _br;
    }
  }

  /// Get page rotation angle
  double getAngle() => angle;

  /// Get flipping progress (0-100)
  double getFlippingProgress() => flippingProgress;

  /// Get the direction of the flip
  FlipDirection getDirection() => direction;

  /// Get the starting position of the shadow
  Offset getShadowStartPoint() {
    if (corner == FlipCorner.top) {
      return topIntersectPoint ?? Offset.zero;
    } else {
      if (sideIntersectPoint != null) return sideIntersectPoint!;
      return topIntersectPoint ?? Offset.zero;
    }
  }

  /// Get the rotate angle of the shadow
  double getShadowAngle() {
    final shadowLine = _getShadowLine();
    final referenceLine = [Offset.zero, Offset(pageWidth, 0)];
    
    final angle = Helper.getAngleBetweenTwoLine(shadowLine, referenceLine);

    if (direction == FlipDirection.forward) {
      return angle;
    }

    return math.pi - angle;
  }

  /// Get shadow line segment
  List<Offset> _getShadowLine() {
    if (corner == FlipCorner.top) {
      return [
        topIntersectPoint ?? position,
        sideIntersectPoint ?? Offset(pageWidth, pageHeight)
      ];
    } else {
      return [
        bottomIntersectPoint ?? position,
        sideIntersectPoint ?? Offset(pageWidth, 0)
      ];
    }
  }

  Offset _calcAngleAndPosition(Offset pos) {
    var result = pos;
    _updateAngleAndGeometry(result);

    if (corner == FlipCorner.top) {
      result = _checkPositionAtCenterLine(result, const Offset(0, 0), Offset(0, pageHeight));
    } else {
      result = _checkPositionAtCenterLine(result, Offset(0, pageHeight), const Offset(0, 0));
    }
    if ((result.dx - pageWidth).abs() < 1 && result.dy.abs() < 1) {
      throw StateError('Point is too small');
    }
    return result;
  }

  void _updateAngleAndGeometry(Offset pos) {
    angle = _calculateAngle(pos);
    _computeRotatedCorners(pos);
  }

  double _calculateAngle(Offset pos) {
    final left = pageWidth - pos.dx + 1;
    final top = corner == FlipCorner.bottom ? pageHeight - pos.dy : pos.dy;
    var a = 2 * math.acos(left / math.sqrt(top * top + left * left));
    if (top < 0) a = -a;
    final da = math.pi - a;
    if (!a.isFinite || (da >= 0 && da < 0.003)) throw StateError('G point too small');
    if (corner == FlipCorner.bottom) a = -a;
    return a;
  }

  void _computeRotatedCorners(Offset origin) {
    // Base rectangle points relative to origin depending on corner
    final points = corner == FlipCorner.top
        ? <Offset>[
            const Offset(0, 0),
            Offset(pageWidth, 0),
            Offset(0, pageHeight),
            Offset(pageWidth, pageHeight),
          ]
        : <Offset>[
            Offset(0, -pageHeight),
            Offset(pageWidth, -pageHeight),
            const Offset(0, 0),
            Offset(pageWidth, 0),
          ];

    Offset rot(Offset p) => Helper.rotatedPoint(p, origin, angle);
    _tl = rot(points[0]);
    _tr = rot(points[1]);
    _bl = rot(points[2]);
    _br = rot(points[3]);

    final left = math.min(math.min(_tl.dx, _tr.dx), math.min(_bl.dx, _br.dx));
    final top = math.min(math.min(_tl.dy, _tr.dy), math.min(_bl.dy, _br.dy));
    final right = math.max(math.max(_tl.dx, _tr.dx), math.max(_bl.dx, _br.dx));
    final bottom = math.max(math.max(_tl.dy, _tr.dy), math.max(_bl.dy, _br.dy));
    _boundingRect = Rect.fromLTRB(left, top, right, bottom);
  }

  void _calculateIntersectPoint(Offset pos) {
    final bound = Rect.fromLTWH(-1, -1, pageWidth + 2, pageHeight + 2);
    Offset? intersect(Offset a1, Offset a2, Offset b1, Offset b2) {
      final ip = _lineIntersection(a1, a2, b1, b2);
      if (ip == null) return null;
      return bound.contains(ip) ? ip : null;
    }

  final rect = _boundingRect!;
    if (corner == FlipCorner.top) {
      topIntersectPoint = intersect(pos, Offset(rect.right, rect.top), const Offset(0, 0), Offset(pageWidth, 0));
      sideIntersectPoint = intersect(pos, Offset(rect.left, rect.bottom), Offset(pageWidth, 0), Offset(pageWidth, pageHeight));
      bottomIntersectPoint = intersect(Offset(rect.left, rect.bottom), Offset(rect.right, rect.bottom), Offset(0, pageHeight), Offset(pageWidth, pageHeight));
    } else {
      topIntersectPoint = intersect(Offset(rect.left, rect.top), Offset(rect.right, rect.top), const Offset(0, 0), Offset(pageWidth, 0));
      sideIntersectPoint = intersect(pos, Offset(rect.left, rect.top), Offset(pageWidth, 0), Offset(pageWidth, pageHeight));
      bottomIntersectPoint = intersect(Offset(rect.left, rect.bottom), Offset(rect.right, rect.bottom), Offset(0, pageHeight), Offset(pageWidth, pageHeight));
    }
  }

  Offset? _lineIntersection(Offset p1, Offset p2, Offset p3, Offset p4) {
    final a1 = p1.dy - p2.dy;
    final a2 = p3.dy - p4.dy;
    final b1 = p2.dx - p1.dx;
    final b2 = p4.dx - p3.dx;
    final c1 = p1.dx * p2.dy - p2.dx * p1.dy;
    final c2 = p3.dx * p4.dy - p4.dx * p3.dy;
    final denom = a1 * b2 - a2 * b1;
    if (denom.abs() < 1e-6) return null;
    final x = -((c1 * b2 - c2 * b1) / denom);
    final y = -((a1 * c2 - a2 * c1) / denom);
    if (x.isFinite && y.isFinite) return Offset(x, y);
    return null;
  }

  Offset _checkPositionAtCenterLine(Offset checked, Offset c1, Offset c2) {
    var result = checked;
    final limited = Helper.limitPointToCircle(c1, pageWidth, result);
    if (limited != result) {
      result = limited;
      _updateAngleAndGeometry(result);
    }
    final radius = math.sqrt(pageWidth * pageWidth + pageHeight * pageHeight);
    Offset checkOne = Offset(rect.right, rect.bottom);
    Offset checkTwo = Offset(rect.left, rect.top);
    if (corner == FlipCorner.bottom) {
      checkOne = Offset(rect.right, rect.top);
      checkTwo = Offset(rect.left, rect.bottom);
    }
    if (checkOne.dx <= 0) {
      final bottomPoint = Helper.limitPointToCircle(c2, radius, checkTwo);
      if (bottomPoint != result) {
        result = bottomPoint;
        _updateAngleAndGeometry(result);
      }
    }
    return result;
  }
}
