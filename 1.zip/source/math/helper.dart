import 'dart:math' as math;
import 'package:flutter/painting.dart';

/// A class containing helping mathematical methods (ported from previous impl).
class Helper {
  static double distance(Offset a, Offset b) => (a - b).distance;

  static Offset rotatedPoint(Offset p, Offset origin, double angle) {
    final s = math.sin(angle);
    final c = math.cos(angle);
    final tx = p.dx;
    final ty = p.dy;
    return Offset(
      tx * c + ty * s + origin.dx,
      ty * c - tx * s + origin.dy,
    );
  }

  static Offset limitPointToCircle(Offset center, double radius, Offset p) {
    final d = distance(center, p);
    if (d <= radius) return p;
    if (d == 0) return center;
    final dir = (p - center) / d;
    return center + dir * radius;
  }

  /// Get angle between two line segments
  static double getAngleBetweenTwoLine(List<Offset> line1, List<Offset> line2) {
    if (line1.length < 2 || line2.length < 2) return 0.0;
    
    final dx1 = line1[1].dx - line1[0].dx;
    final dy1 = line1[1].dy - line1[0].dy;
    final dx2 = line2[1].dx - line2[0].dx;
    final dy2 = line2[1].dy - line2[0].dy;
    
    final angle1 = math.atan2(dy1, dx1);
    final angle2 = math.atan2(dy2, dx2);
    
    return (angle1 - angle2).abs();
  }

  static List<Offset> lerpPoints(Offset pointOne, Offset pointTwo) {
    final sizeX = (pointOne.dx - pointTwo.dx).abs();
    final sizeY = (pointOne.dy - pointTwo.dy).abs();

    final lengthLine = math.max(sizeX, sizeY);

    final result = <Offset>[pointOne];

    double getCord(
      double c1,
      double c2,
      double size,
      double length,
      int index,
    ) {
      if (c2 > c1) {
        return c1 + index * (size / length);
      } else if (c2 < c1) {
        return c1 - index * (size / length);
      }
      return c1;
    }

    for (int i = 1; i <= lengthLine; i += 1) {
      result.add(
        Offset(
          getCord(pointOne.dx, pointTwo.dx, sizeX, lengthLine, i),
          getCord(pointOne.dy, pointTwo.dy, sizeY, lengthLine, i),
        ),
      );
    }

    return result;
  }
}
