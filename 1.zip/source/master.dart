/// Native RenderObject-based page flip implementation
/// 
/// This is the new implementation that renders real Flutter widgets
/// instead of converting to images, enabling interactive child widgets.
library turnable_page_native;

// Core widget and controller
export 'turnable_page_view.dart';
export 'controller/native_page_flip_controller.dart';

// Enums and types
export 'render/turnable_render_box.dart' show FlipState;
export 'enums/flip_corner.dart';
export 'enums/flip_direction.dart';

// Models
export 'model/point.dart';
export 'model/shadow.dart';

// Helper types for page building
export 'turnable_page_view.dart' show NativePageBuilder;
