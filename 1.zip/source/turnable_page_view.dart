import 'package:flutter/widgets.dart';
import 'controller/native_page_flip_controller.dart';
import 'render/turnable_render_box.dart';

typedef NativePageBuilder = Widget Function(int index, BoxConstraints constraints);

/// Native RenderObject-based page flip widget with interactive child widgets.
/// 
/// This widget provides realistic page-turning animations with full gesture support
/// and renders real Flutter widgets (not converted to images) so internal gestures work.
class TurnablePageFlip extends StatefulWidget {
  const TurnablePageFlip({
    super.key,
    required this.pageCount,
    required this.pageBuilder,
    this.controller,
    this.onPageChanged,
    this.aspectRatio = 2 / 3,
  });

  final int pageCount;
  final NativePageBuilder pageBuilder;
  final PageFlipControllerr? controller;
  final void Function(int left, int right)? onPageChanged;
  final double aspectRatio; // width / height for a single page

  @override
  State<TurnablePageFlip> createState() => _TurnablePageFlipState();
}

class _TurnablePageFlipState extends State<TurnablePageFlip> {
  late RenderTurnablePageView _renderObject;
  final Map<int, Widget> _cache = {};

  @override
  void initState() {
    super.initState();
    _renderObject = RenderTurnablePageView(
      pageCount: widget.pageCount,
      builder: _buildPage,
      onPageChanged: (leftPage, rightPage) {
        widget.onPageChanged?.call(leftPage, rightPage);
        widget.controller?.updatePage(leftPage);
      },
      onStateChanged: (state) {
        // Handle state changes if needed
      },
      onAnimationChanged: (isAnimating) {
        widget.controller?.updateAnimating(isAnimating);
      },
      invalidate: () => setState(() {}),
      aspectRatio: widget.aspectRatio,
      showCornerPreview: true,
      swipeDistance: 30.0,
      animationDuration: const Duration(milliseconds: 700),
    );
    
    widget.controller?.attach(
      pageCount: widget.pageCount,
      currentPage: 0,
      next: () => _renderObject.next(),
      prev: () => _renderObject.prev(),
      goTo: (i) => _renderObject.goTo(i),
    );
  }

  @override
  void didUpdateWidget(covariant TurnablePageFlip oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.pageCount != widget.pageCount) {
      _renderObject.pageCount = widget.pageCount;
      widget.controller?.attach(
        pageCount: widget.pageCount,
        currentPage: _renderObject.currentPage,
        next: () => _renderObject.next(),
        prev: () => _renderObject.prev(),
        goTo: (i) => _renderObject.goTo(i),
      );
    }
  }

  Widget _buildPage(int index, BoxConstraints c) {
    return ConstrainedBox(
      constraints: BoxConstraints.tightFor(width: c.maxWidth, height: c.maxHeight),
      child: _cache[index] ??= widget.pageBuilder(index, c),
    );
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        return _TurnableRenderObjectWidget(
          renderObject: _renderObject,
          pageCount: widget.pageCount,
          builder: (index, _) => widget.pageBuilder(
            index,
            BoxConstraints.tightFor(
              width: constraints.maxWidth,
              height: constraints.maxHeight,
            ),
          ),
        );
      },
    );
  }
}

class _TurnableRenderObjectWidget extends RenderObjectWidget {
  const _TurnableRenderObjectWidget({
    required this.renderObject,
    required this.pageCount,
    required this.builder,
  });

  final RenderTurnablePageView renderObject;
  final int pageCount;
  final Widget Function(int, BoxConstraints) builder;

  @override
  RenderObjectElement createElement() => _TurnableElement(this);

  @override
  RenderObject createRenderObject(BuildContext context) => renderObject;
}

class _TurnableElement extends RenderObjectElement {
  _TurnableElement(_TurnableRenderObjectWidget super.widget);

  RenderTurnablePageView get _render => (widget as _TurnableRenderObjectWidget).renderObject;

  final Map<int, Element> _pageElements = {};

  @override
  void mount(Element? parent, Object? newSlot) {
    super.mount(parent, newSlot);
    _buildInitialChildren();
  }

  void _buildInitialChildren() {
    _ensureChildForIndex(_render.currentPage);
    if (!_render.isPortrait && _render.currentPage + 1 < _render.pageCount) {
      _ensureChildForIndex(_render.currentPage + 1);
    }
    
    // Ensure we have children for potential animation
    if (_render.hasNext) {
      _ensureChildForIndex(_render.currentPage + 1);
    }
    if (_render.hasPrev) {
      _ensureChildForIndex(_render.currentPage - 1);
    }
  }

  void _ensureChildForIndex(int index) {
    if (_pageElements.containsKey(index)) return;
    final built = (widget as _TurnableRenderObjectWidget).builder(
      index,
      const BoxConstraints(),
    );
    final newChild = updateChild(null, built, index);
    if (newChild != null) _pageElements[index] = newChild;
  }

  @override
  void update(covariant _TurnableRenderObjectWidget newWidget) {
    super.update(newWidget);
    rebuild();
  }

  @override
  void performRebuild() {
    super.performRebuild();
    final needed = <int>{_render.currentPage};
    
    // Add right page for landscape mode
    if (!_render.isPortrait && _render.currentPage + 1 < _render.pageCount) {
      needed.add(_render.currentPage + 1);
    }
    
    // Add flipping page during animation
    if (_render.state == FlipState.animating || _render.state == FlipState.dragging) {
      if (_render.hasNext) {
        needed.add(_render.currentPage + 1);
      }
      if (_render.hasPrev) {
        needed.add(_render.currentPage - 1);
      }
    }
    
    final toRemove = _pageElements.keys.where((k) => !needed.contains(k)).toList();
    for (final k in toRemove) {
      final el = _pageElements.remove(k);
      if (el != null) updateChild(el, null, k);
    }
    for (final k in needed) {
      _ensureChildForIndex(k);
    }
  }

  @override
  void insertRenderObjectChild(RenderBox child, int slot) {
    _render.add(child);
    final pd = child.parentData as TurnableParentData;
    pd.index = slot;
  }

  @override
  void moveRenderObjectChild(RenderBox child, int oldSlot, int newSlot) {}

  @override
  void removeRenderObjectChild(RenderBox child, int slot) {
    _render.remove(child);
  }
}
