import 'dart:math' as math;
import '../enums/flip_corner.dart';
import '../enums/flip_direction.dart';
import '../model/point.dart';

/// Flip calculation for page turning animations
/// This is a simplified version that provides the interface needed by RenderTurnablePageView
class FlipCalculation {
  final FlipDirection direction;
  final FlipCorner corner;
  final double pageWidth;
  final double pageHeight;
  
  Point _position = const Point(0, 0);
  double _angle = 0.0;
  double _progress = 0.0;

  FlipCalculation(this.direction, this.corner, this.pageWidth, this.pageHeight);

  /// Current flip position
  Point get position => _position;

  /// Calculate flip based on current position
  bool calc(Point pos) {
    _position = pos;
    
    // Simple angle calculation based on position
    final centerX = pageWidth / 2;
    final centerY = pageHeight / 2;
    
    // Calculate angle from center to current position
    final dx = pos.x - centerX;
    final dy = pos.y - centerY;
    _angle = math.atan2(dy, dx);
    
    // Calculate progress (0-100) based on distance from right edge
    final distanceFromEdge = (pageWidth - pos.x.abs()).clamp(0.0, pageWidth);
    _progress = ((pageWidth - distanceFromEdge) / pageWidth * 100).clamp(0.0, 100.0);
    
    return true;
  }

  /// Get the active corner point for rotation
  Point getActiveCorner() {
    switch (corner) {
      case FlipCorner.top:
        return direction == FlipDirection.forward 
            ? Point(pageWidth, 0) 
            : const Point(0, 0);
      case FlipCorner.bottom:
        return direction == FlipDirection.forward 
            ? Point(pageWidth, pageHeight) 
            : Point(0, pageHeight);
    }
  }

  /// Get the rotation angle
  double getAngle() => _angle;

  /// Get flip direction
  FlipDirection getDirection() => direction;

  /// Get flipping progress (0-100)
  double getFlippingProgress() => _progress;

  /// Get shadow start point
  Point getShadowStartPoint() {
    // Shadow starts from the fold line
    switch (corner) {
      case FlipCorner.top:
        return Point(_position.x, 0);
      case FlipCorner.bottom:
        return Point(_position.x, pageHeight);
    }
  }

  /// Get shadow angle
  double getShadowAngle() {
    // Shadow angle is perpendicular to the fold
    return _angle + math.pi / 2;
  }
}
