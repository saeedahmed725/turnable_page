/// A point in 2D space
class Point {
  /// X coordinate
  final double x;
  
  /// Y coordinate  
  final double y;

  /// Create a point with the given coordinates
  const Point(this.x, this.y);

  @override
  String toString() => 'Point($x, $y)';

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is Point && runtimeType == other.runtimeType && x == other.x && y == other.y;

  @override
  int get hashCode => x.hashCode ^ y.hashCode;
}
