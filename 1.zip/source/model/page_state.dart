import 'package:flutter/foundation.dart';
import 'package:flutter/rendering.dart';

/// Mutable state describing a single page during a flip animation.
class PageState with Diagnosticable {
  /// Active corner (in page coordinate space) while flipping.
  Offset position = Offset.zero;

  /// Rotation angle (radians) applied around [position].
  double angle = 0.0;

  /// Additional "hard page" angle (cover stiffness). Reserved for future.
  double hardAngle = 0.0;

  /// Area polygon (page local coordinates) describing visible portion
  /// of the flipping page (clip path). Empty means full page.
  List<Offset> area = const [];

  PageState copy() => PageState()
    ..position = position
    ..angle = angle
    ..hardAngle = hardAngle
    ..area = List.of(area);
}
