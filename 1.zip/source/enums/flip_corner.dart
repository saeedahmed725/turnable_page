/// Enum for page flip corners
enum FlipCorner {
  /// Top corner of the page
  top,
  /// Bottom corner of the page
  bottom,
}
