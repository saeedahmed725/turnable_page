/// Enum for page flip direction
enum FlipDirection {
  /// Flipping forward (left to right)
  forward,
  /// Flipping backward (right to left)
  back,
}
