import 'package:flutter/foundation.dart';

/// Controller for the native (RenderObject based) page flip widget.
/// 
/// Provides programmatic control over page navigation, state monitoring,
/// and event listening capabilities similar to the original implementation.
class PageFlipControllerr with ChangeNotifier {
  int _currentPage = 0;
  int _pageCount = 0;
  bool _isAnimating = false;
  
  // Internal methods from render object
  void Function()? _next;
  void Function()? _prev;
  void Function(int)? _goTo;
  
  // Event listeners
  final Map<String, List<VoidCallback>> _listeners = {};

  /// Current page index (0-based)
  int get currentPage => _currentPage;
  
  /// Total number of pages
  int get pageCount => _pageCount;
  
  /// Whether a flip animation is currently in progress
  bool get isAnimating => _isAnimating;

  /// Check if there is a next page available
  bool get hasNext => _currentPage < _pageCount - 1;

  /// Check if there is a previous page available  
  bool get hasPrev => _currentPage > 0;

  /// Internal method to attach the render object
  void attach({
    required int pageCount,
    required int currentPage,
    required void Function() next,
    required void Function() prev,
    required void Function(int) goTo,
  }) {
    _pageCount = pageCount;
    _currentPage = currentPage;
    _next = next;
    _prev = prev;
    _goTo = goTo;
    notifyListeners();
  }

  /// Internal method to update current page (for render object)
  void updatePage(int page) {
    if (page != _currentPage) {
      final oldPage = _currentPage;
      _currentPage = page;
      notifyListeners();
      _trigger('flip', {'page': page, 'oldPage': oldPage});
    }
  }

  /// Internal method to update animation state (for render object)
  void updateAnimating(bool animating) {
    if (animating != _isAnimating) {
      _isAnimating = animating;
      _trigger(animating ? 'animationStart' : 'animationComplete', null);
      notifyListeners();
    }
  }

  /// Flip to the next page with animation
  /// Returns true if the flip was successful, false if already at the last page
  bool nextPage() {
    if (!hasNext || _isAnimating) return false;
    updateAnimating(true);
    _next?.call();
    return true;
  }

  /// Flip to the previous page with animation  
  /// Returns true if the flip was successful, false if already at the first page
  bool previousPage() {
    if (!hasPrev || _isAnimating) return false;
    updateAnimating(true);
    _prev?.call();
    return true;
  }

  /// Go to a specific page with animation
  /// Returns true if navigation was successful, false if page index is invalid
  bool goToPage(int pageIndex) {
    if (pageIndex < 0 || pageIndex >= _pageCount || _isAnimating) return false;
    if (pageIndex == _currentPage) return true;
    updateAnimating(true);
    _goTo?.call(pageIndex);
    return true;
  }

  /// Go to the first page
  bool goToFirstPage() => goToPage(0);

  /// Go to the last page  
  bool goToLastPage() => goToPage(_pageCount - 1);

  /// Register an event listener
  /// 
  /// Available events:
  /// - 'flip': Page changed (data: {page: int, oldPage: int})
  /// - 'animationStart': Animation started
  /// - 'animationComplete': Animation finished  
  /// - 'init': Widget initialized
  void addEventListener(String event, VoidCallback callback) {
    _listeners.putIfAbsent(event, () => []).add(callback);
  }

  /// Remove an event listener
  void removeEventListener(String event, VoidCallback callback) {
    _listeners[event]?.remove(callback);
    if (_listeners[event]?.isEmpty ?? false) {
      _listeners.remove(event);
    }
  }

  /// Remove all listeners for an event
  void removeAllListeners(String event) {
    _listeners.remove(event);
  }

  /// Trigger an event
  void _trigger(String event, dynamic data) {
    final callbacks = _listeners[event];
    if (callbacks != null) {
      for (final callback in List.from(callbacks)) {
        callback();
      }
    }
  }

  @override
  void dispose() {
    _listeners.clear();
    super.dispose();
  }
}
