import 'dart:math' as math;
import 'dart:ui' as ui;
import 'package:flutter/gestures.dart'; // For hover/exit events
import 'package:flutter/rendering.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/widgets.dart' show Widget, BoxConstraints; // builder types
import '../enums/flip_corner.dart';
import '../enums/flip_direction.dart';
import '../math/flip_calculation.dart';
import '../math/helper.dart';
import '../model/page_state.dart';

typedef PageChangedCallback = void Function(int leftPage, int rightPage);
typedef StateChangedCallback = void Function(FlipState state);
typedef AnimationCallback = void Function(bool isAnimating);

/// Current state of the page flip widget
enum FlipState { 
  /// Widget is idle, ready for interaction
  idle,
  /// User is actively dragging a page corner  
  dragging,
  /// Page flip animation is running
  animating,
  /// Mouse hovering over corner (showing preview fold)
  cornerHover,
}

enum _FlipPhase { idle, dragging, animating }

/// Enhanced data for each page in the render tree
class TurnableParentData extends ContainerBoxParentData<RenderBox> {
  int index = 0;
  PageState state = PageState();
}

// Internal shadow representation (kept local to source implementation)
class _LocalShadow {
  final Offset pos;
  final double angle;
  final double width;
  final double opacity;
  final FlipDirection direction;
  final double progress;
  const _LocalShadow({
    required this.pos,
    required this.angle,
    required this.width,
    required this.opacity,
    required this.direction,
    required this.progress,
  });
}

/// Enhanced RenderObject with comprehensive flip features matching original implementation
class RenderTurnablePageView extends RenderBox
    with
        ContainerRenderObjectMixin<RenderBox, TurnableParentData>,
        RenderBoxContainerDefaultsMixin<RenderBox, TurnableParentData> {
  RenderTurnablePageView({
    required int pageCount,
    required this.builder,
    required this.onPageChanged,
    required this.onStateChanged,
    required this.onAnimationChanged,
    required this.invalidate,
    required double aspectRatio,
    this.showCornerPreview = true,
    this.swipeDistance = 30.0,
    this.animationDuration = const Duration(milliseconds: 700),
  })  : _pageCount = pageCount,
        _aspectRatio = aspectRatio;

  final Widget Function(int index, BoxConstraints constraints) builder;
  final PageChangedCallback? onPageChanged;
  final StateChangedCallback? onStateChanged;
  final AnimationCallback? onAnimationChanged;
  final VoidCallback invalidate;
  final bool showCornerPreview;
  final double swipeDistance;
  final Duration animationDuration;

  int _currentPage = 0;
  int _pageCount;
  double _aspectRatio;
  bool _isPortrait = true;

  // Enhanced flip state
  _FlipPhase _phase = _FlipPhase.idle;
  FlipState _state = FlipState.idle;
  FlipCalculation? _calc;
  FlipDirection? _direction;
  FlipCorner? _corner;
  late double _pageWidth;
  late double _pageHeight;
  late double _spreadLeft;

  // Swipe detection
  Offset? _touchStartPos;
  int? _touchStartTime;
  final int _swipeTimeoutMs = 250;

  // Animation
  List<Offset> _animPoints = const [];
  int _animIndex = 0;
  late final Ticker _ticker = Ticker(_tick);
  late int _animStartMillis;
  bool _onAnimationEndTurned = false;

  // Corner preview
  Offset? _hoveredCorner;

  // Shadow system
  _LocalShadow? _shadow;
  bool _drawShadow = true; // enable/disable shadows externally
  double _maxShadowOpacity = 0.6; // matches original default

  set pageCount(int value) {
    if (value == _pageCount) return;
    _pageCount = value;
    markNeedsLayout();
  }

  set aspectRatio(double value) {
    if (value == _aspectRatio) return;
    _aspectRatio = value;
    markNeedsLayout();
  }

  int get currentPage => _currentPage;
  bool get isPortrait => _isPortrait;
  int get pageCount => _pageCount;
  FlipState get state => _state;

  void _setState(FlipState newState) {
    if (_state != newState) {
      _state = newState;
      onStateChanged?.call(newState);
      invalidate(); // Trigger element rebuild for state changes
    }
  }

  void _setAnimating(bool animating) {
    onAnimationChanged?.call(animating);
  }

  @override
  bool hitTestSelf(Offset position) => true;

  @override
  bool hitTestChildren(BoxHitTestResult result, {required Offset position}) {
    // First, let children handle the hit test (for interactive widgets)
    RenderBox? child = lastChild; // Test from top to bottom
    while (child != null) {
      final TurnableParentData childParentData = child.parentData! as TurnableParentData;
      final pageOffset = _pageOffsetForIndex(childParentData.index);
      
      // Check if this child should be visible and hit-testable
      if (_shouldPaintChild(childParentData.index)) {
        final hit = result.addWithPaintOffset(
          offset: pageOffset,
          position: position,
          hitTest: (BoxHitTestResult result, Offset transformed) {
            return child!.hitTest(result, position: transformed);
          },
        );
        if (hit) return true;
      }
      
      child = childParentData.previousSibling;
    }
    
    return false;
  }

  bool _shouldPaintChild(int index) {
    final leftIndex = _currentPage;
    final rightIndex = _isPortrait ? -1 : (_currentPage + 1 < _pageCount ? _currentPage + 1 : -1);
    
    return index == leftIndex || 
           index == rightIndex || 
           (_calc != null && index == (_direction == FlipDirection.forward ? leftIndex + 1 : leftIndex));
  }

  @override
  void handleEvent(PointerEvent event, covariant HitTestEntry entry) {
    // Only handle events for page flipping if they're on corners or during drag
    if (event is PointerDownEvent) {
      if (_pointOnCorners(event.localPosition)) {
        _handleDown(event.localPosition);
      }
    } else if (event is PointerMoveEvent) {
      if (_phase == _FlipPhase.dragging) {
        _handleMove(event.localPosition);
      } else if (showCornerPreview && _pointOnCorners(event.localPosition)) {
        _handleHover(event.localPosition);
      }
    } else if (event is PointerUpEvent || event is PointerCancelEvent) {
      if (_phase == _FlipPhase.dragging) {
        _handleUp(event.localPosition);
      }
    } else if (event is PointerHoverEvent && showCornerPreview) {
      _handleHover(event.localPosition);
    } else if (event is PointerExitEvent) {
      _clearCornerPreview();
    }
    
    // Note: Events not handled here will propagate to child widgets
  }

  bool _pointOnCorners(Offset global) {
    final rect = _bookRect();
    final operatingDistance = math.sqrt(
          _pageWidth * _pageWidth + _pageHeight * _pageHeight,
        ) /
        5;
    if (!rect.contains(global)) return false;
    final x = global.dx - rect.left;
    final y = global.dy - rect.top;
    return (x < operatingDistance || x > rect.width - operatingDistance) &&
        (y < operatingDistance || y > rect.height - operatingDistance);
  }

  void _handleDown(Offset pos) {
    if (_phase == _FlipPhase.animating) return;
    _touchStartPos = pos;
    _touchStartTime = DateTime.now().millisecondsSinceEpoch;
    _clearCornerPreview();
    
    // Only start drag if touch is on corners
    if (_pointOnCorners(pos)) {
      _startDrag(pos);
    }
  }

  void _handleMove(Offset pos) {
    if (_phase != _FlipPhase.dragging) return;
    _updateDrag(pos);
  }

  void _handleUp(Offset pos) {
    if (_phase == _FlipPhase.dragging) {
      _checkSwipeGesture(pos);
      _finishDrag(pos);
    }
    _touchStartPos = null;
    _touchStartTime = null;
  }

  void _handleHover(Offset pos) {
    if (_phase != _FlipPhase.idle) return;
    
    if (_pointOnCorners(pos)) {
      if (_hoveredCorner != pos) {
        _hoveredCorner = pos;
        _showCornerPreview(pos);
      }
    } else {
      _clearCornerPreview();
    }
  }

  void _showCornerPreview(Offset pos) {
    _setState(FlipState.cornerHover);
    // Small corner fold preview (simplified for now)
    markNeedsPaint();
  }

  void _clearCornerPreview() {
    if (_state == FlipState.cornerHover) {
      _setState(FlipState.idle);
      _hoveredCorner = null;
      markNeedsPaint();
    }
  }

  void _checkSwipeGesture(Offset endPos) {
    if (_touchStartPos == null || _touchStartTime == null) return;
    
    final elapsed = DateTime.now().millisecondsSinceEpoch - _touchStartTime!;
    if (elapsed > _swipeTimeoutMs) return;
    
    final delta = endPos - _touchStartPos!;
    final distance = delta.distance;
    final distanceY = delta.dy.abs();
    
    if (distance > swipeDistance && distanceY < swipeDistance * 2) {
      // Valid swipe gesture
      if (delta.dx > 0 && hasPrev) {
        // Swipe right - go to previous page
        _startProgrammatic(FlipDirection.back);
        return;
      } else if (delta.dx < 0 && hasNext) {
        // Swipe left - go to next page  
        _startProgrammatic(FlipDirection.forward);
        return;
      }
    }
  }

  bool get hasNext => _currentPage < _pageCount - 1;
  bool get hasPrev => _currentPage > 0;

  void _startDrag(Offset global) {
    final rect = _bookRect();
    final local = Offset(global.dx - rect.left, global.dy - rect.top);
  // Direction logic replicated from original getDirectionByPoint:
  // In portrait: if touch.x - pageWidth <= bookWidth/5 => back else forward.
  // In landscape: left half => back else forward.
  final pageWidthLogical = _pageWidth; // single page width
  final forward = _isPortrait
    ? !((local.dx - pageWidthLogical) <= rect.width / 5)
    : !(local.dx < rect.width / 2);
    _direction = forward ? FlipDirection.forward : FlipDirection.back;
    _corner = local.dy >= rect.height / 2 ? FlipCorner.bottom : FlipCorner.top;
    _calc = FlipCalculation(
      _direction!,
      _corner!,
      _pageWidth,
      _pageHeight,
    );
    _phase = _FlipPhase.dragging;
    _updateDrag(global);
  }

  void _updateDrag(Offset global) {
    if (_calc == null) return;
    final rect = _bookRect();
    final bookPos = Offset(global.dx - rect.left, global.dy - rect.top);
    Offset pagePos;
    if (_direction == FlipDirection.forward) {
      pagePos = Offset(bookPos.dx - rect.width / 2, bookPos.dy);
    } else {
      pagePos = Offset(rect.width / 2 - bookPos.dx, bookPos.dy);
    }
    if (_calc!.calc(pagePos)) {
      // Calculate shadow data
      final progress = _calc!.getFlippingProgress();
      _setShadowData(
        _calc!.getShadowStartPoint(),
        _calc!.getShadowAngle(),
        progress,
        _calc!.getDirection(),
      );
      
      // Trigger repaint immediately during drag for smooth interaction
      markNeedsPaint();
    }
  }

  void _finishDrag(Offset global) {
    if (_calc == null) return;
    final pos = _calc!.position;
    final turned = pos.dx <= 0;
    final rect = _bookRect();
    final y = _corner == FlipCorner.bottom ? rect.height : 0.0;
    final start = pos;
    final dest = turned ? Offset(-_pageWidth, y) : Offset(_pageWidth, y);
    _animateTo(start, dest, turned);
  }

  void _animateTo(Offset start, Offset dest, bool turned) {
    print('DEBUG: Starting animation from $start to $dest, turned: $turned');
    _animPoints = Helper.lerpPoints(start, dest);
    _animIndex = 0;
    _phase = _FlipPhase.animating;
    _setState(FlipState.animating);
    _setAnimating(true);
    
    // Calculate duration based on frame count like original
    final frameCount = _animPoints.length;
    final totalDuration = frameCount >= 1000 
        ? animationDuration.inMilliseconds 
        : (frameCount / 1000.0 * animationDuration.inMilliseconds);
    
    _animStartMillis = DateTime.now().millisecondsSinceEpoch;
    _onAnimationEndTurned = turned;
    
    if (!_ticker.isActive) _ticker.start();
    print('DEBUG: Animation started, ${_animPoints.length} frames, duration: ${totalDuration}ms');
  }

  void _tick(Duration _) {
    if (_phase != _FlipPhase.animating || _animPoints.isEmpty) {
      _ticker.stop();
      return;
    }
    
    final elapsed = DateTime.now().millisecondsSinceEpoch - _animStartMillis;
    final frameCount = _animPoints.length;
    final totalDuration = frameCount >= 1000 
        ? animationDuration.inMilliseconds 
        : (frameCount / 1000.0 * animationDuration.inMilliseconds);
    
    // Frame-based animation like original
    final frameIndex = ((elapsed / totalDuration) * frameCount)
        .clamp(0, frameCount - 1)
        .floor();
    
    if (frameIndex != _animIndex) {
      _animIndex = frameIndex;
      if (_calc != null) {
        _calc!.calc(_animPoints[_animIndex]);
        
        // Calculate shadow data during animation
        final progress = _calc!.getFlippingProgress();
        _setShadowData(
          _calc!.getShadowStartPoint(),
          _calc!.getShadowAngle(),
          progress,
          _calc!.getDirection(),
        );
        
        markNeedsPaint();
      }
    }
    
    if (elapsed >= totalDuration) {
      print('DEBUG: Animation completed, applying turn: $_onAnimationEndTurned');
      _ticker.stop();
      if (_onAnimationEndTurned) _applyTurn();
      _resetFlip();
      _setState(FlipState.idle);
      _setAnimating(false);
    }
  }

  void _applyTurn() {
    if (_direction == FlipDirection.forward && _currentPage < _pageCount - 1) {
      _currentPage += 1;
    } else if (_direction == FlipDirection.back && _currentPage > 0) {
      _currentPage -= 1;
    }
    onPageChanged?.call(
      _currentPage,
      _currentPage + 1 < _pageCount ? _currentPage + 1 : -1,
    );
    invalidate(); // Trigger element rebuild for page changes
  }

  void next() {
    print('DEBUG: next() called, phase: $_phase, currentPage: $_currentPage, pageCount: $_pageCount');
    if (_phase != _FlipPhase.idle) return;
    if (_currentPage >= _pageCount - 1) return;
    _startProgrammatic(FlipDirection.forward);
  }

  void prev() {
    print('DEBUG: prev() called, phase: $_phase, currentPage: $_currentPage');
    if (_phase != _FlipPhase.idle) return;
    if (_currentPage <= 0) return;
    _startProgrammatic(FlipDirection.back);
  }

  void goTo(int index) {
    if (index < 0 || index >= _pageCount) return;
    _currentPage = index;
    markNeedsPaint();
    onPageChanged?.call(
      _currentPage,
      _currentPage + 1 < _pageCount ? _currentPage + 1 : -1,
    );
  }

  @override
  void setupParentData(RenderBox child) {
    if (child.parentData is! TurnableParentData) {
      child.parentData = TurnableParentData();
    }
  }

  void _resetFlip() {
    _phase = _FlipPhase.idle;
    _calc = null;
    _direction = null;
    _corner = null;
    _clearShadow();
    _setState(FlipState.idle);
  }

  void _startProgrammatic(FlipDirection direction) {
    print('DEBUG: _startProgrammatic called with direction: $direction');
    _direction = direction;
    _corner = FlipCorner.top;
    _calc = FlipCalculation(direction, _corner!, _pageWidth, _pageHeight);
    final start = Offset(_pageWidth - 10, 1);
    _calc!.calc(start);
    final dest = direction == FlipDirection.forward
        ? Offset(-_pageWidth, 0)
        : Offset(_pageWidth, 0);
    _animateTo(start, dest, true);
  }

  // Helper: compute page rect within this render box
  Rect _bookRect() {
  // Keep logical width always two * pageWidth for consistent coordinate transforms like original implementation.
  final logicalWidth = _pageWidth * 2;
  return Rect.fromLTWH(_spreadLeft, 0, logicalWidth, _pageHeight);
  }

  Offset _pageOffsetForIndex(int index) {
    final leftIndex = _currentPage;
    // Always position current (left) page at spreadLeft, right page at spreadLeft + pageWidth
    if (index == leftIndex) {
      // In portrait mode current page is drawn on right half (original behavior)
      if (_isPortrait) {
        return Offset(_spreadLeft + _pageWidth, 0);
      }
      return Offset(_spreadLeft, 0);
    }
    if (!_isPortrait && index == leftIndex + 1) return Offset(_spreadLeft + _pageWidth, 0);
    // Potential flipping targets
    if (_phase != _FlipPhase.idle && _direction != null) {
      if (_direction == FlipDirection.forward) {
        // Forward uses current as flipping, reveals next => need next page for bottom
        if (index == leftIndex + 1) {
          // Bottom page (next) sits under on right half portrait, on right page in landscape
          if (_isPortrait) return Offset(_spreadLeft + _pageWidth, 0);
          return Offset(_spreadLeft + _pageWidth, 0);
        }
      } else {
        // Backward uses previous page as flipping
        if (index == leftIndex - 1) {
          if (_isPortrait) return Offset(_spreadLeft + _pageWidth, 0); // previous page as flipping shown on right half
          return Offset(_spreadLeft, 0);
        }
      }
    }
    return const Offset(-10000, -10000);
  }

  void _setShadowData(Offset pos, double angle, double progress, FlipDirection direction) {
    if (!_drawShadow) return;
    // Width & opacity formula copied from original CanvasRender.setShadowData
    final maxShadowOpacity = 100 * _maxShadowOpacity; // original multiplies by 100 then scales
    final basePageWidth = _pageWidth; // rect.pageWidth equivalent
    final width = (((basePageWidth * 3) / 4) * progress) / 100; // progress 0-100
    final opacity = ((100 - progress) * maxShadowOpacity) / 100 / 100; // final 0-1
    _shadow = _LocalShadow(
      pos: pos,
      angle: angle,
      width: width,
      opacity: opacity,
      direction: direction,
      progress: progress * 2, // original sets progress*2 (used for hardness)
    );
  }
  void _clearShadow() { _shadow = null; }

  void _drawOuterShadow(Canvas canvas, Rect rect) {
    if (_shadow == null || !_drawShadow) return;
    canvas.save();
    canvas.clipRect(rect);
    final shadowPos = _convertToGlobal(_shadow!.pos);
    if (shadowPos == null) { canvas.restore(); return; }
    canvas.translate(shadowPos.dx, shadowPos.dy);
    canvas.rotate(math.pi + _shadow!.angle + math.pi / 2);
    final paint = Paint();
    late List<Color> colors; late List<double> stops;
    if (_shadow!.direction == FlipDirection.forward) {
      canvas.translate(0, -100);
      colors = [Color.fromARGB((_shadow!.opacity * 255).round(),0,0,0), const Color.fromARGB(0,0,0,0)];
      stops = [0.0,1.0];
    } else {
      canvas.translate(-_shadow!.width, -100);
      colors = [const Color.fromARGB(0,0,0,0), Color.fromARGB((_shadow!.opacity * 255).round(),0,0,0)];
      stops = [0.0,1.0];
    }
    paint.shader = ui.Gradient.linear(const Offset(0,0), Offset(_shadow!.width,0), colors, stops);
    canvas.drawRect(Rect.fromLTWH(0,0,_shadow!.width, rect.height*2), paint);
    canvas.restore();
  }

  void _drawInnerShadow(Canvas canvas, Rect rect, Path? clipPath) {
    if (_shadow == null || !_drawShadow || clipPath == null) return;
    canvas.save();
    canvas.clipPath(clipPath);
    final shadowPos = _convertToGlobal(_shadow!.pos);
    if (shadowPos == null) { canvas.restore(); return; }
    canvas.translate(shadowPos.dx, shadowPos.dy);
    canvas.rotate(math.pi + _shadow!.angle + math.pi / 2);
    final isw = (_shadow!.width * 3)/4;
    final paint = Paint();
    late List<Color> colors; late List<double> stops;
    if (_shadow!.direction == FlipDirection.forward) {
      canvas.translate(-isw, -100);
      colors = [
        const Color.fromARGB(0,0,0,0),
        Color.fromARGB((_shadow!.opacity * 0.05 * 255).round(),0,0,0),
        Color.fromARGB((_shadow!.opacity * 255).round(),0,0,0),
        Color.fromARGB((_shadow!.opacity * 255).round(),0,0,0),
      ];
      stops = [0.0,0.7,0.9,1.0];
    } else {
      canvas.translate(0,-100);
      colors = [
        Color.fromARGB((_shadow!.opacity * 255).round(),0,0,0),
        Color.fromARGB((_shadow!.opacity * 0.05 * 255).round(),0,0,0),
        Color.fromARGB((_shadow!.opacity * 255).round(),0,0,0),
        const Color.fromARGB(0,0,0,0),
      ];
      stops = [0.0,0.1,0.3,1.0];
    }
    paint.shader = ui.Gradient.linear(const Offset(0,0), Offset(isw,0), colors, stops);
    canvas.drawRect(Rect.fromLTWH(0,0,isw, rect.height*2), paint);
    canvas.restore();
  }

  Offset _transformLocalPoint(Offset p, Rect spreadRect) {
    final midX = spreadRect.left + spreadRect.width / 2;
    final x = _direction == FlipDirection.forward ? midX + p.dx : midX - p.dx;
    final y = p.dy + spreadRect.top;
    return Offset(x, y);
  }

  Offset? _convertToGlobal(Offset? pos) {
    if (pos == null) return null;
    final rect = _bookRect();
    final x = _direction == FlipDirection.forward ? pos.dx + rect.left + rect.width / 2 : rect.width / 2 - pos.dx + rect.left;
    return Offset(x, pos.dy + rect.top);
  }

  @override
  void performLayout() {
    final maxW = constraints.maxWidth.isFinite ? constraints.maxWidth : 0.0;
    final maxH = constraints.maxHeight.isFinite ? constraints.maxHeight : 0.0;
    final cw = maxW == 0 ? 300.0 : maxW;
    final ch = maxH == 0 ? 400.0 : maxH;
    _isPortrait = cw < ch * 1.2;
  _pageHeight = ch;
  final maxLogicalWidth = _isPortrait ? cw : cw / 2;
  _pageWidth = math.min(maxLogicalWidth, _pageHeight * _aspectRatio);
  final midX = cw / 2;
  _spreadLeft = _isPortrait
    ? (midX - _pageWidth / 2 - _pageWidth) // center logical 2*pageWidth so visible page is right half
    : (midX - _pageWidth); // two pages visible
    size = constraints.constrain(Size(cw, ch));

    RenderBox? child = firstChild;
    while (child != null) {
      child.layout(
        BoxConstraints.tight(Size(_pageWidth, _pageHeight)),
        parentUsesSize: true,
      );
      child = childAfter(child);
    }
  }

  @override
  void paint(PaintingContext context, Offset offset) {
    _paintBackground(context, offset);
  _paintSpineShadow(context, offset);
    final rect = _bookRect().translate(offset.dx, offset.dy);
    final leftIndex = _currentPage;
    final rightIndex =
        _isPortrait ? -1 : (_currentPage + 1 < _pageCount ? _currentPage + 1 : -1);
    
    // Determine flipping + bottom page indices (portrait logic first)
    int? flippingIndex;
    int? bottomIndex;
    if (_calc != null && (_phase == _FlipPhase.dragging || _phase == _FlipPhase.animating)) {
      if (_direction == FlipDirection.forward) {
        // Flip current page to reveal next
        flippingIndex = leftIndex;
        bottomIndex = leftIndex + 1 < _pageCount ? leftIndex + 1 : null;
      } else if (_direction == FlipDirection.back) {
        // Flip previous page back to cover current
        flippingIndex = leftIndex - 1 >= 0 ? leftIndex - 1 : null;
        bottomIndex = leftIndex;
      }
    }

    RenderBox? child = firstChild;
    while (child != null) {
      final pd = child.parentData as TurnableParentData;
      final pageOffset = _pageOffsetForIndex(pd.index) + offset;

      if (pd.index == flippingIndex) {
        _paintFlippingPage(context, child, pageOffset, rect, flippingIndex!, bottomIndex, offset);
      } else if (pd.index == bottomIndex) {
        // Bottom page (revealed) gets painted normally unless also needs clip later by flipping page path
        context.paintChild(child, pageOffset);
      } else if (pd.index == leftIndex && flippingIndex != leftIndex) {
        context.paintChild(child, pageOffset);
      } else if (pd.index == rightIndex && flippingIndex != rightIndex) {
        context.paintChild(child, pageOffset);
      }
      child = childAfter(child);
    }
  }

  void _paintBackground(PaintingContext context, Offset offset) {
    final canvas = context.canvas;
    final paint = Paint()..color = const Color(0xFFEFEFEF);
  final rect = _bookRect().translate(offset.dx, offset.dy);
    canvas.drawRRect(
      RRect.fromRectAndRadius(rect, const Radius.circular(4)),
      paint,
    );
  }

  void _paintSpineShadow(PaintingContext context, Offset offset) {
    if (!_drawShadow) return;
    final canvas = context.canvas;
    final rect = _bookRect().translate(offset.dx, offset.dy);
    final shadowSize = rect.width / 40; // subtle spine shadow
    canvas.save();
    canvas.clipRect(rect);
    final sx = rect.left + rect.width / 2 - shadowSize / 2;
    final paint = Paint()
      ..shader = ui.Gradient.linear(
        Offset(sx, rect.top),
        Offset(sx + shadowSize, rect.top),
        [
          const Color.fromARGB(0, 0, 0, 0),
          Color.fromARGB((0.2 * 255).round(), 0, 0, 0),
          Color.fromARGB((0.1 * 255).round(), 0, 0, 0),
          Color.fromARGB((0.5 * 255).round(), 0, 0, 0),
          Color.fromARGB((0.4 * 255).round(), 0, 0, 0),
          const Color.fromARGB(0, 0, 0, 0),
        ],
        const [0.0, 0.4, 0.49, 0.5, 0.51, 1.0],
      );
    canvas.drawRect(Rect.fromLTWH(sx, rect.top, shadowSize, rect.height * 2), paint);
    canvas.restore();
  }

  void _paintFlippingPage(
    PaintingContext context,
    RenderBox flippingChild,
    Offset flippingOffset,
    Rect spreadRect,
    int flippingIndex,
    int? bottomIndex,
    Offset baseOffset,
  ) {
    if (_calc == null) {
      context.paintChild(flippingChild, flippingOffset);
      return;
    }

    final canvas = context.canvas;
    canvas.save();

    try {
      // Areas
      final flipPoly = _calc!.getFlippingClipArea();
      final bottomPoly = _calc!.getBottomClipArea();

      // Draw bottom (static) page clipped to bottomPoly first if present
      if (bottomIndex != null && bottomPoly.length >= 3) {
        final bottomChild = _childForIndex(bottomIndex);
        if (bottomChild != null) {
          final bottomPath = _buildGlobalPath(bottomPoly, spreadRect);
          canvas.save();
          canvas.clipPath(bottomPath);
          context.paintChild(bottomChild, baseOffset);
          canvas.restore();
        }
      }

      if (flipPoly.length < 3) {
        context.paintChild(flippingChild, flippingOffset);
        return;
      }

      final clipPath = _buildGlobalPath(flipPoly, spreadRect);

  // Pivot at active corner (matches original math orientation) and sign adjust by direction
  final baseAngle = _calc!.getAngle();
  final rotAngle = _direction == FlipDirection.forward ? -baseAngle : baseAngle;
  final activeCorner = _calc!.getActiveCorner();
  final pivotGlobal = _transformLocalPoint(activeCorner, spreadRect);
      final transform = Matrix4.identity()
        ..translate(pivotGlobal.dx, pivotGlobal.dy)
        ..rotateZ(rotAngle)
        ..translate(-pivotGlobal.dx, -pivotGlobal.dy);

      // Clip to flipping polygon
      canvas.save();
      canvas.clipPath(clipPath);

      // Front face
      context.pushTransform(
        needsCompositing,
        flippingOffset,
        transform,
        (context, offset) {
          context.paintChild(flippingChild, offset);
        },
      );

  // Back face (simple white with faint content tint)
  final backsideOpacity = 0.12 + 0.18 * (1 - math.cos(baseAngle).abs());
      final backPaint = Paint()
        ..color = const Color(0xFFFFFFFF).withOpacity(backsideOpacity)
        ..blendMode = BlendMode.srcOver;
      canvas.drawPath(clipPath, backPaint);
  // Draw shadows AFTER page so they appear above (original renders last)
  _drawOuterShadow(canvas, spreadRect);
  _drawInnerShadow(canvas, spreadRect, clipPath);

      canvas.restore();
    } catch (_) {
      context.paintChild(flippingChild, flippingOffset);
    } finally {
      canvas.restore();
    }
  }

  Path _buildGlobalPath(List<Offset> localPoly, Rect spreadRect) {
    final path = Path();
    for (int i = 0; i < localPoly.length; i++) {
      final gp = _transformLocalPoint(localPoly[i], spreadRect);
      if (i == 0) {
        path.moveTo(gp.dx, gp.dy);
      } else {
        path.lineTo(gp.dx, gp.dy);
      }
    }
    path.close();
    return path;
  }

  RenderBox? _childForIndex(int index) {
    RenderBox? child = firstChild;
    while (child != null) {
      final data = child.parentData as TurnableParentData;
      if (data.index == index) return child;
      child = childAfter(child);
    }
    return null;
  }
}
